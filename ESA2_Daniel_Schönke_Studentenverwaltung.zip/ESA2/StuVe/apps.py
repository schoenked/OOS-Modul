from django.apps import AppConfig


class StuveConfig(AppConfig):
    name = 'StuVe'
